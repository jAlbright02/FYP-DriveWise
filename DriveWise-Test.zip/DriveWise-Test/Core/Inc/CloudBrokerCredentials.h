/*
 * CloudBrokerCredentials.h
 *
 *  Created on: Nov 11, 2022
 *      Author: nokeeffe
 */

#ifndef INC_CLOUDBROKERCREDENTIALS_H_
#define INC_CLOUDBROKERCREDENTIALS_H_

#define CloudBroker_HostName "industrial.api.ubidots.com"

#define CloudBroker_Port "8883"

#define CloudBroker_Username "BBUS-2pKVH91JG2LEz2pPnx1rfGdLATyydA"

#define CloudBroker_Password ""

#define CloudBroker_ClientID "67e17bdde4af5d331b993744"


#endif /* INC_CLOUDBROKERCREDENTIALS_H_ */
