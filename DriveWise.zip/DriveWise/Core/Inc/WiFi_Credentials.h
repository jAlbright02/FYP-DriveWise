/*
 * WiFi_Credentials.h
 *
 *  Created on: 16 Oct 2022
 *      Author: nokeeffe
 */

#ifndef INC_WIFI_CREDENTIALS_H_
#define INC_WIFI_CREDENTIALS_H_

#define SSID     "AndroidAP_1236"
#define PASSWORD "12345678"

#endif /* INC_WIFI_CREDENTIALS_H_ */
