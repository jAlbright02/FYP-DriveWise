//Enums for CAN PIDs

#ifndef CAN_PIDS_H
#define CAN_PIDS_H

typedef enum {
    RPM = 0x0C,//RPM
    ENGINE_COOLANT_TEMP = 0x05,//ECT
    MASS_AIR_FLOW = 0x10,//MAF
    ENGINE_LOAD = 0x04,//LOAD
	THROTTLE_POS = 0x11, //APP
    VEHICLE_SPEED = 0x0D,//VSS
    FUEL_LEVEL = 0x2F,//FLI
	//Diesel Only
    AMBIENT_TEMP = 0x46,//AAT
    MANIFOLD_PRESSURE = 0x0B,//MAP
    BARO_PRESSURE = 0x33//BARO
} OBD2_PID;


#endif // CAN_PIDS_H
