/*
 * driveWiseApp.h
 *
 *  Created on: Dec 02, 2024
 *      Author: James Albright
 */

#ifndef INC_DRIVEWISEAPP_H_
#define INC_DRIVEWISEAPP_H_

#include <stdio.h>
#include <string.h>

void userApp();
extern int _write(int file, char *ptr, int len);
void TIM6_Handler();

#endif /* INC_DRIVEWISEAPP_H_ */
