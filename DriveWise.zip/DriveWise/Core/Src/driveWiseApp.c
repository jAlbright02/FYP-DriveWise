/*
 * driveWiseApp.c
 * Author: James.Albright@atu.ie
 */

#include "main.h"
#include "driveWiseApp.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "event_groups.h"
#include "stm32l4xx_hal_can.h"
#include "CAN_PIDs.h"
#include "brokerConnect.h"


//Peripheral Handles
extern UART_HandleTypeDef huart1;

//Can and timer definitions
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim6;

CAN_RxHeaderTypeDef RxHeader;
uint8_t RxData[8] = {0, 0, 0, 0, 0, 0, 0, 0};

//RTOS task function prototypes and object declarations
static void initTask(void * pvParameters);
static void CAN_Task(void * pvParameters);
static void MQTT_Task(void * pvParameters);
static void CAN_Tx_Request(uint8_t requestedPID);
static void CAN_Rx_Receive(uint8_t requestedPID);

TaskHandle_t canTaskHandle;
TaskHandle_t mqttTaskHandle;
SemaphoreHandle_t publishSemaphore = NULL;
QueueHandle_t mqttQueueHandle;
char rxPayload[50];

//CAN Interrupt Handler
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
	if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK) {
		switch (RxData[2]) {
		 case RPM:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //Shift first byte to the left by 8bits, add the other byte then scale down
			 uint16_t vehicleRPM = (((RxData[3] * 256 + RxData[4])/4));
			 printf("Vehicle RPM: %d rpm\r\n", vehicleRPM);
			 sprintf(rxPayload, "{\"rpm\":%d}", vehicleRPM);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case VEHICLE_SPEED:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t vehicleSpeed = RxData[3];
			 printf("Vehicle Speed: %d km\\h\r\n", vehicleSpeed);
			 sprintf(rxPayload, "{\"speed\":%d}", vehicleSpeed);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case ENGINE_COOLANT_TEMP:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t engineCoolTemp = RxData[3] - 40;
			 printf("Engine Coolant Temperature: %dC\r\n", engineCoolTemp);
			 sprintf(rxPayload, "{\"engCoolTemp\":%d}", engineCoolTemp);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case MASS_AIR_FLOW:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-655
			 uint16_t massAF = ((RxData[3] * 256 + RxData[4])/100);
			 printf("Mass Airflow: %d g/s\r\n", massAF);
			 sprintf(rxPayload, "{\"mass_af\":%d}", massAF);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case ENGINE_LOAD:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-100
			 uint8_t engLoad = (RxData[3]*100)/255;
			 printf("Engine Load: %d%%\r\n", engLoad);
			 sprintf(rxPayload, "{\"engload\":%d}", engLoad);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case FUEL_LEVEL:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-100
			 uint8_t fuel_lvl = (RxData[3]*100)/255;
			 printf("Fuel Level: %d%%\r\n", fuel_lvl);
			 sprintf(rxPayload, "{\"fuel_lvl\":%d}", fuel_lvl);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case AMBIENT_TEMP:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range -40-215
			 int16_t ambtemp = RxData[3] - 40;
			 printf("Ambient Air Temp: %dC\r\n", ambtemp);
			 sprintf(rxPayload, "{\"ambtemp\":%d}", ambtemp);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case MANIFOLD_PRESSURE:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t man_press = RxData[3];
			 printf("Manifold Absolute Pressure: %dkPa\r\n", man_press);
			 sprintf(rxPayload, "{\"man_press\":%d}", man_press);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case BARO_PRESSURE:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t bar_press = RxData[3];
			 printf("Barometric Pressure: %dkPa\r\n", bar_press);
			 sprintf(rxPayload, "{\"bar_press\":%d}", bar_press);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case THROTTLE_POS:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t throt_pos = (RxData[3]*100)/255;
			 printf("Throttle Position: %d%%\r\n", throt_pos);
			 sprintf(rxPayload, "{\"throt_pos\":%d}", throt_pos);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 default:
			 break;
		}
	}
}

void TIM6_Handler() {
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(publishSemaphore, &xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void MQTT_Task(void *pvParameters) {
    char publishMsg[50];
    while (1) {
        if (xQueueReceive(mqttQueueHandle, publishMsg, portMAX_DELAY) == pdPASS) {
            MQTTMessage mqmsg;
            memset(&mqmsg, 0, sizeof(MQTTMessage));
            mqmsg.payload = publishMsg;
            mqmsg.payloadlen = strlen(publishMsg);
            mqmsg.qos = QOS0;

            if (MQTTPublish(&client, "/v1.6/devices/drivewise", &mqmsg) != SUCCESS) {
                printf("MQTTPublish failed\r\n");
            } else {
                printf("Message published: %s\r\n\n", publishMsg);
            }
        }
    }
}

/*--------------------------------------
 * Initialisation Task
 * 1. Connects to ubidots MQTT broker
 * 3. Creates semaphores
 * 8. Task deletes itself
 ----------------------------------------*/
static void initTask(void * pvParameters) {
	printf("Starting Init Task\r\n");
	while(1) {
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
		brokerConnect(&client);

		if (xTaskCreate(CAN_Task, "CAN_Task", 500, NULL, configMAX_PRIORITIES - 4, &canTaskHandle) == pdTRUE) {
			printf("CAN task created\n\r");
		}
		else {
			printf("Could not create CAN task\n\r");
		}

		if (xTaskCreate(MQTT_Task, "MQTT Task", 500, NULL, configMAX_PRIORITIES - 3, &mqttTaskHandle) == pdTRUE) {
			printf("MQTT task created\n\r");
		}
		else {
			printf("Could not create MQTT task\n\r");
		}

		publishSemaphore = xSemaphoreCreateBinary();
		vQueueAddToRegistry(publishSemaphore, "Publish Semaphore");

		mqttQueueHandle = xQueueCreate(5, 50);

		__HAL_TIM_CLEAR_IT(&htim6, TIM_IT_UPDATE);
		HAL_NVIC_GetPendingIRQ(TIM6_DAC_IRQn);
		HAL_TIM_Base_Start_IT(&htim6);

		printf("Deleting Init Task\r\n\n");
		vTaskDelete(NULL);
	}
}

/*-----------------------------------------------
 * User application function
 * Creates Init task and starts ROS scheduler
-------------------------------------------------*/
void userApp() {
	printf("DriveWise V1\r\n\n");
	xTaskCreate(initTask, "Init Task", 800, NULL, configMAX_PRIORITIES - 1, NULL);
	vTaskStartScheduler();
	while(1) {
	}
}

//CAN Code
void CAN_Tx_Request(uint8_t requestedPID) {
    CAN_TxHeaderTypeDef TxHeader;
    uint8_t TxData[8] = {0x02, 0x01, requestedPID, 0x55, 0x55, 0x55, 0x55, 0x55};
    uint32_t TxMailbox;

    //Configure CAN header (Data length, )
    TxHeader.DLC = 8;
    TxHeader.StdId = 0x7DF;
    TxHeader.IDE = CAN_ID_STD;
    TxHeader.RTR = CAN_RTR_DATA;

    HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

}

void CAN_Task(void *pvParameters) {

    while (1) { //try port max delay, only run when semaphore given
    	if (xSemaphoreTake(publishSemaphore, portMAX_DELAY) == pdTRUE) {
    		printf("Speed Requested...\r\n\n");
			CAN_Tx_Request(VEHICLE_SPEED);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("RPM Requested...\r\n\n");
			CAN_Tx_Request(RPM);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Eng. Coolant Temp Requested...\r\n\n");
			CAN_Tx_Request(ENGINE_COOLANT_TEMP);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Mass Air Flow Requested...\r\n\n");
			CAN_Tx_Request(MASS_AIR_FLOW);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Engine Load Requested...\r\n\n");
			CAN_Tx_Request(ENGINE_LOAD);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Fuel Level Requested...\r\n\n");
			CAN_Tx_Request(FUEL_LEVEL);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Ambient Air Temperature Requested...\r\n\n");
			CAN_Tx_Request(AMBIENT_TEMP);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Manifold Absolute Pressure Requested...\r\n\n");
			CAN_Tx_Request(MANIFOLD_PRESSURE);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Barometric Pressure Requested...\r\n\n");
			CAN_Tx_Request(BARO_PRESSURE);
			vTaskDelay(pdMS_TO_TICKS(10));

			printf("Throttle Position Requested...\r\n\n");
			CAN_Tx_Request(THROTTLE_POS);
			vTaskDelay(pdMS_TO_TICKS(10));
    	}
    }
}
