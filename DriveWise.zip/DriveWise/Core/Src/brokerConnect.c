/*
 * brokerConnect.c
 *
 *  Created on: Nov 29, 2024
 *      Author: Niall O'Keefe
 */

#include "main.h"
#include "stm32l4xx_hal_can.h"
#include "brokerConnect.h"

//Network variables
extern int network_wr(Network* n, unsigned char* buffer, int len, int timeout_ms);
extern int network_rd(Network* n, unsigned char* buffer, int len, int timeout_ms);
extern int net_if_init(void * if_ctxt);
extern int net_if_deinit(void * if_ctxt);
extern int net_if_reinit(void * if_ctxt);
extern int wifi_net_if_init(void * if_ctxt);

//Required by brokerConnect
net_hnd_t hnet;
Network network;
MQTTPacket_connectData options = MQTTPacket_connectData_initializer;
net_sockhnd_t socket;
MQTTClient client;
typedef struct {
  char *HostName;
  char *HostPort;
  char *ConnSecurity;
  char *MQClientId;
  char *MQUserName;
  char *MQUserPwd;
#ifdef LITMUS_LOOP
  char *LoopTopicId;
#endif
} device_config_t;

/*--------------------------------------------------------------------
 * EXTI interrupt handler callback function
 * Will give a semaphore when the user button is pressed
 --------------------------------------------------------------------*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch (GPIO_Pin)
	{
	case (GPIO_PIN_1):
		{
		SPI_WIFI_ISR();
		break;
		}
	default:
	{
		break;
	}
	}
}

/*-------------------------------------------------
 * Function to establish connection to cloud server
 * 1. Connects to WiFi access point (AP)
 * 2. Connects to ubidots web server
 * 3. Connects to Ubidots MQTT broker
---------------------------------------------------*/
void brokerConnect(MQTTClient * client) {
	int32_t ret;
	//Network and MQTT variables
	device_config_t MQTT_Config;
	static unsigned char mqtt_send_buffer[MQTT_SEND_BUFFER_SIZE];
	static unsigned char mqtt_read_buffer[MQTT_READ_BUFFER_SIZE];
	net_ipaddr_t ipAddr;
	net_macaddr_t macAddr;


	//Initialise MQTT broker structure
	//Fill in this section with MQTT broker credentials from header file
	MQTT_Config.HostName = CloudBroker_HostName;
	MQTT_Config.HostPort = CloudBroker_Port;
	MQTT_Config.ConnSecurity = "0";	//plain TCP connection with no security
	MQTT_Config.MQUserName = CloudBroker_Username;
	MQTT_Config.MQUserPwd = CloudBroker_Password;
	MQTT_Config.MQClientId = CloudBroker_ClientID;

	//Initialise WiFi network
	if (net_init(&hnet, NET_IF, (wifi_net_if_init)) != NET_OK) {
		printf("\n\rError");
	}
	else {
		printf("\n\rOK");
	}
	HAL_Delay(500);

	printf("\n\rRetrieving the IP address.");

	if (net_get_ip_address(hnet, &ipAddr) != NET_OK) {
		printf("\n\rError 2");
	}
	else
	{
		switch(ipAddr.ipv) {
			case NET_IP_V4:
				printf("\n\rIP address: %d.%d.%d.%d\n\r", ipAddr.ip[12], ipAddr.ip[13], ipAddr.ip[14], ipAddr.ip[15]);
				break;
			case NET_IP_V6:
			default:
				printf("\n\rError 3");
		}
	}

	if (net_get_mac_address(hnet, &macAddr) == NET_OK) {
		printf("\n\rMac Address: %02x:%02x:%02x:%02x:%02x:%02x\r\n",
	               macAddr.mac[0], macAddr.mac[1], macAddr.mac[2], macAddr.mac[3], macAddr.mac[4], macAddr.mac[5]);
	}

	printf("Connecting to MQTT Broker Server\r\n\n");
	//Create network socket
	ret = net_sock_create(hnet, &socket, NET_PROTO_TCP);
	if (ret != NET_OK)
	{
		printf("\n\rCould not create the socket.\r\n");
		printf("Check MQTT broker configuration settings.\r\n");
		while(1);
	}
	else
	{
		ret |= net_sock_setopt(socket, "sock_noblocking", NULL, 0);
	}

	ret = net_sock_open(socket, MQTT_Config.HostName, 1883, 0);
	if (ret != NET_OK)
	{
		printf("\n\rCould not open the socket.");
		while(1);
	}
	else {
		printf("\r\nConnected to MQTT Broker Server\r\n");
		HAL_Delay(1000);
	}

	network.my_socket = socket;
	network.mqttread = (network_rd);
	network.mqttwrite = (network_wr);

	MQTTClientInit(client, &network, MQTT_CMD_TIMEOUT, mqtt_send_buffer, MQTT_SEND_BUFFER_SIZE,
			mqtt_read_buffer, MQTT_READ_BUFFER_SIZE);

	/* MQTT connect */
	options.clientID.cstring = MQTT_Config.MQClientId;
	options.username.cstring = MQTT_Config.MQUserName;
	options.password.cstring = MQTT_Config.MQUserPwd;

	HAL_Delay(1000);

	printf("Connecting client to MQTT Broker\r\n\n");
	ret = MQTTConnect(client, &options);
	if (ret != 0)
	{
		printf("\n\rMQTTConnect() failed: %ld\n", ret);
		printf("Check MQTT client credential settings.\r\n");
		while(1);
	}
	else
	{
		printf("\n\rClient Connected to MQTT Broker\r\n");
		HAL_Delay(1000);
	}
	HAL_Delay(1000);

}

