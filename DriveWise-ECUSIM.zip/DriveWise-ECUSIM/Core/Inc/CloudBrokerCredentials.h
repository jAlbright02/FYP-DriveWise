/*
 * CloudBrokerCredentials.h
 *
 *  Created on: Nov 11, 2022
 *      Author: nokeeffe
 */

#ifndef INC_CLOUDBROKERCREDENTIALS_H_
#define INC_CLOUDBROKERCREDENTIALS_H_

#define CloudBroker_HostName "industrial.api.ubidots.com"

#define CloudBroker_Port "8883"

#define CloudBroker_Username "BBUS-5lqxaVyinQif5vMxy3Q4jXIwTcoN1t"

#define CloudBroker_Password ""

#define CloudBroker_ClientID "6807838e6e4eb30c98b272d4"


#endif /* INC_CLOUDBROKERCREDENTIALS_H_ */
