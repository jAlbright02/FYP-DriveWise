/*
 * uaerApp.h
 *
 *  Created on: Dec 12, 2023
 *      Author: Niall.OKeeffe@atu.ie
 */

#ifndef INC_USERAPP_H_
#define INC_USERAPP_H_

#include <stdio.h>
#include <string.h>

void userApp();
extern int _write(int file, char *ptr, int len);
void TIM6_Handler();

#endif /* INC_USERAPP_H_ */
