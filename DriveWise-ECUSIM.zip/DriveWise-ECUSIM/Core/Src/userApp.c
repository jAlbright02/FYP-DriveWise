/*
 * userApp.c
 * Author: James.Albright@atu.ie
 */

#include "main.h"
#include "userApp.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "event_groups.h"
#include "stm32l4xx_hal_can.h"
#include "CAN_PIDs.h"
#include "brokerConnect.h"


//Peripheral Handles
extern UART_HandleTypeDef huart1;

//Can and timer definitions
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim6;

CAN_RxHeaderTypeDef RxHeader;
uint8_t RxData[8] = {0, 0, 0, 0, 0, 0, 0, 0};

//RTOS task function prototypes and object declarations
static void initTask(void * pvParameters);
static void CAN_Task(void * pvParameters);
static void MQTT_Task(void * pvParameters);
static void CAN_Tx_Request(uint8_t requestedPID);

TaskHandle_t canTaskHandle;
TaskHandle_t mqttTaskHandle;
SemaphoreHandle_t publishSemaphore = NULL;
QueueHandle_t mqttQueueHandle;
char rxPayload[50];

//CAN Interrupt Handler
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
	if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK) {
		switch (RxData[2]) {
		 case RPM:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //Shift first byte to the left by 8bits, add the other byte then scale down
			 uint16_t vehicleRPM = (((RxData[3] * 256 + RxData[4])/4)*9000)/16383;
			 printf("Vehicle RPM: %d rpm\r\n", vehicleRPM);
			 sprintf(rxPayload, "{\"rpm\":%d}", vehicleRPM);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case VEHICLE_SPEED:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //POT doesn't hit 0, so -4 is needed. The range is moved down to 0-140
			 uint8_t vehicleSpeed = ((RxData[3] - 4) * 140) / 255;
			 printf("Vehicle Speed: %d km\\h\r\n", vehicleSpeed);
			 sprintf(rxPayload, "{\"speed\":%d}", vehicleSpeed);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case ENGINE_COOLANT_TEMP:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //Want temp to be in range -40-215
			 int16_t engineCoolTemp = RxData[3] - 40;
			 printf("Engine Coolant Temperature: %dC\r\n", engineCoolTemp);
			 sprintf(rxPayload, "{\"engCoolTemp\":%d}", engineCoolTemp);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case MASS_AIR_FLOW:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-655
			 uint16_t massAF = ((RxData[3] * 256 + RxData[4])/100);
			 printf("Mass Airflow: %d g/s\r\n", massAF);
			 sprintf(rxPayload, "{\"mass_af\":%d}", massAF);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case ENGINE_LOAD:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-100
			 uint8_t engLoad = (RxData[3]*100)/255;
			 printf("Engine Load: %d%%\r\n", engLoad);
			 sprintf(rxPayload, "{\"engload\":%d}", engLoad);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case FUEL_LEVEL:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range 0-100
			 uint8_t fuel_lvl = (RxData[3]*100)/255;
			 printf("Fuel Level: %d%%\r\n", fuel_lvl);
			 sprintf(rxPayload, "{\"fuel_lvl\":%d}", fuel_lvl);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case AMBIENT_TEMP:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 //range -40-200
			 int16_t ambtemp = RxData[3] - 40;
			 printf("Ambient Air Temp: %dC\r\n", ambtemp);
			 sprintf(rxPayload, "{\"ambtemp\":%d}", ambtemp);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case MANIFOLD_PRESSURE:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t man_press = RxData[3];
			 printf("Manifold Absolute Pressure: %dkPa\r\n", man_press);
			 sprintf(rxPayload, "{\"man_press\":%d}", man_press);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 case BARO_PRESSURE:
			 printf("Got message : id = 0x%04lx len = 0x%lx, data=%02x%02x%02x%02x%02x%02x%02x%02x\r\n", RxHeader.StdId, RxHeader.DLC, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
			 uint8_t bar_press = RxData[3];
			 printf("Barometric Pressure: %dkPa\r\n", bar_press);
			 sprintf(rxPayload, "{\"bar_press\":%d}", bar_press);
			 if (xQueueSendFromISR(mqttQueueHandle, rxPayload, NULL) != pdPASS) {
				 printf("Queue send failed\r\n");
			 }
			 break;

		 default:
			 break;
		}
	}
}

void TIM6_Handler() {
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(publishSemaphore, &xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void MQTT_Task(void *pvParameters) {
    char publishMsg[50];
    while (1) {
        if (xQueueReceive(mqttQueueHandle, publishMsg, portMAX_DELAY) == pdPASS) {
            MQTTMessage mqmsg;
            memset(&mqmsg, 0, sizeof(MQTTMessage));
            mqmsg.payload = publishMsg;
            mqmsg.payloadlen = strlen(publishMsg);
            mqmsg.qos = QOS0;

            //original endpoint for ubidots /v1.6/devices/drivewise
            if (MQTTPublish(&client, "/v1.6/devices/drivewise", &mqmsg) != SUCCESS) {
                printf("MQTTPublish failed\r\n");
            } else {
                printf("Message published: %s\r\n\n", publishMsg);
            }
        }
    }
}

/*--------------------------------------
 * Initialisation Task
 * 1. Connects to ubidots MQTT broker
 * 3. Creates semaphores
 * 8. Task deletes itself
 ----------------------------------------*/
static void initTask(void * pvParameters) {
	printf("Starting Init Task\r\n");
	while(1) {
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
		brokerConnect(&client);

		if (xTaskCreate(CAN_Task, "CAN_Task", 1024, NULL, configMAX_PRIORITIES - 4, &canTaskHandle) == pdTRUE) {
			printf("CAN task created\n\r");
		}
		else {
			printf("Could not create CAN task\n\r");
		}

		if (xTaskCreate(MQTT_Task, "MQTT Task", 1024, NULL, configMAX_PRIORITIES - 3, &mqttTaskHandle) == pdTRUE) {
			printf("MQTT task created\n\r");
		}
		else {
			printf("Could not create MQTT task\n\r");
		}

		publishSemaphore = xSemaphoreCreateBinary();
		vQueueAddToRegistry(publishSemaphore, "Publish Semaphore");

		mqttQueueHandle = xQueueCreate(5, 50);

		__HAL_TIM_CLEAR_IT(&htim6, TIM_IT_UPDATE);
		HAL_NVIC_GetPendingIRQ(TIM6_DAC_IRQn);
		HAL_TIM_Base_Start_IT(&htim6);

		printf("Deleting Init Task\r\n\n");
		vTaskDelete(NULL);
	}
}

/*-----------------------------------------------
 * User application function
 * Creates Init task and starts ROS scheduler
-------------------------------------------------*/
void userApp() {
	printf("DriveWise V1\r\n\n");
	xTaskCreate(initTask, "Init Task", 2048, NULL, configMAX_PRIORITIES - 1, NULL);
	vTaskStartScheduler();
	while(1) {
	}
}

//CAN Code
void CAN_Tx_Request(uint8_t requestedPID) {
    CAN_TxHeaderTypeDef TxHeader;
    uint8_t TxData[8] = {0x02, 0x01, requestedPID, 0x55, 0x55, 0x55, 0x55, 0x55};
    uint32_t TxMailbox;

    //Configure CAN header (Data length, Broadcast Identifier, Standard 11bit, Carries Data)
    TxHeader.DLC = 8;
    TxHeader.StdId = 0x7DF;
    TxHeader.IDE = CAN_ID_STD;
    TxHeader.RTR = CAN_RTR_DATA;

    HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

}

void CAN_Task(void *pvParameters) {
	uint8_t rotating_index = 0;
	uint16_t demo_count = 0;

	while (1) { //try port max delay, only run when semaphore given
		//this is done to stop ubidots from limiting my requests
		const uint8_t ROTATING_PIDS[] = {
			ENGINE_COOLANT_TEMP,
			MASS_AIR_FLOW,
			FUEL_LEVEL,
			AMBIENT_TEMP,
			MANIFOLD_PRESSURE,
			BARO_PRESSURE
		};
		const uint8_t NUM_ROTATING = sizeof(ROTATING_PIDS)/sizeof(ROTATING_PIDS[0]);

		if (xSemaphoreTake(publishSemaphore, portMAX_DELAY) == pdTRUE) {
			printf("Speed Requested...\r\n\n");
			CAN_Tx_Request(VEHICLE_SPEED);
			vTaskDelay(pdMS_TO_TICKS(50));

			printf("RPM Requested...\r\n\n");
			CAN_Tx_Request(RPM);
			vTaskDelay(pdMS_TO_TICKS(50));

			printf("Engine Load Requested...\r\n\n");
			CAN_Tx_Request(ENGINE_LOAD);
			vTaskDelay(pdMS_TO_TICKS(50));

			// Send one rotating parameter
			printf("Requested PID: 0x%02X...\r\n\n", ROTATING_PIDS[rotating_index]);
			CAN_Tx_Request(ROTATING_PIDS[rotating_index]);
			vTaskDelay(pdMS_TO_TICKS(50));

			// Update index for next rotation
			rotating_index = (rotating_index + 1) % NUM_ROTATING;

			if(++demo_count >= 120) { // 2min then pause to cool down ubidots
				demo_count = 0;
				vTaskDelay(pdMS_TO_TICKS(2000));
			}
		}
		vTaskDelay(pdMS_TO_TICKS(100));
	}
}
