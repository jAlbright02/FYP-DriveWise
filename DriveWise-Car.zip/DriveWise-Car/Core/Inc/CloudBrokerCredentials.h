/*
 * CloudBrokerCredentials.h
 *
 *  Created on: Nov 11, 2022
 *      Author: nokeeffe
 */

#ifndef INC_CLOUDBROKERCREDENTIALS_H_
#define INC_CLOUDBROKERCREDENTIALS_H_

#define CloudBroker_HostName "industrial.api.ubidots.com"

#define CloudBroker_Port "8883"

#define CloudBroker_Username "BBUS-IkMP5UXfhDB2i4Sa7JEEOWS3Z3XYnk"

#define CloudBroker_Password ""

#define CloudBroker_ClientID "68078693a277780edd9893a0"


#endif /* INC_CLOUDBROKERCREDENTIALS_H_ */
